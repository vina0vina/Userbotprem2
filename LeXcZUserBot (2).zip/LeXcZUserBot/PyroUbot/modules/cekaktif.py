import asyncio
from pyrogram import Client, filters
from pyrogram.types import Message
from PyroUbot.core.helpers.msg_type import ReplyCheck
from PyroUbot import *


__MODULE__ = "ᴀʟɪᴠᴇ"
__HELP__ = f"""
『 ʙᴀɴᴛᴜᴀɴ ᴜɴᴛᴜᴋ ᴀʟɪᴠᴇ 』

• ᴘᴇʀɪɴᴛᴀʜ: <code>.alive</code>
• ᴘᴇɴᴊᴇʟᴀsᴀɴ: ᴜɴᴛᴜᴋ ᴍᴇɴɢᴇᴄᴇᴋ ᴍᴀsᴀ ᴀᴋᴛɪғ ᴜsᴇʀʙᴏᴛ
"""
